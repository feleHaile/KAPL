from animalvan import AnimalVan

class StunAStoat(AnimalVan):
    def __init__(self):
        super().__init__('stoat','stun')
