#!/usr/bin/env python

import sys   # <1>

print(sys.argv) # <2>

name = sys.argv[1]  # <3>
print("name is", name)
