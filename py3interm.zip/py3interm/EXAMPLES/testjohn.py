#!/usr/bin/python3

import john

print(john.add(1,10000))

john.system("ls -l")

