#!/usr/bin/env python

"""
Example module.
"""

def spam():
    print("Hello from spam()")

def ham():
    print("Hello from ham()")

def _eggs():
    print("Hello from _eggs()")

