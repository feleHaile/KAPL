#!/usr/bin/env python
# (c)2015 John Strickler
'''
Script/module docs
'''
import sys

# other imports  (standard library, standard non-library, local)

# globals

# main function
def main(args):
    '''
    Main docs...
    :param args:
    :return:
    '''
    pass

# other functions
def function1():
    '''
    Function docs
    :return:
    '''
    pass

if __name__ == '__main__':
    main(sys.argv[1:])
