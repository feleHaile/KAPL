

int add(int, int);

void hello(void);

char *get_skit(int);
