from animalvan import AnimalVan

class AmazeAVole(AnimalVan):
    def __init__(self):
        super().__init__('vole','amaze')
