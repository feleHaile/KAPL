#!/usr/bin/env python
from samplelib import * # <1>

spam()  # <2>
ham()

