from distutils.core import setup
setup(
    name='temperature',
    version='1.2',
    description='Class for converting temperatures',
    author='John Strickler',
    author_email='jstrick@mindspring.com',
    url='http://www.cja-tech.com/temperat',
    py_modules=['temperature'],
)
