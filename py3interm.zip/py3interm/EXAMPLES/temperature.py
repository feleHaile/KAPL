#!/usr/bin/python

import sys

class Temperature(object):
    
    def __init__(self,temp_f):
        self._temp_f = temp_f
        
    @property
    def Fahrenheit(self):
        pass

    @property
    def Celsius(self):
        pass

    @property
    def Kelvin(self):
        pass

    @property
    def Fahrenheit(self):
        pass

