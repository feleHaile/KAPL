#!/usr/bin/python3

from tkinter import *
top = Tk()
lab1 = Label(top,text="Hello, Tk World")
lab1.pack()
top.mainloop()
