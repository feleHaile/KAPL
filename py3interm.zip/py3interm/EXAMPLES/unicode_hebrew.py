#!/usr/bin/env python
# (c)2015 John Strickler
#

shalom = u'\u05e9\u05dc\u05d5\u05dd'

print(shalom)
