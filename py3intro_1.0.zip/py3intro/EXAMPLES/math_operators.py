#!/usr/bin/env python

x = 22
x += 10  # <1>

y = 5
y *= 3  # <1>

print("x:", x)
print("y:", y)

print("2 ** 16", 2 ** 16)

print("x / y", x / y)
print("x // y", x // y)  # <2>

