
import tkinter as tk

mw = tk.Tk()

b1 = tk.Button(mw,text="Click me")
b1.pack()



mw.mainloop()